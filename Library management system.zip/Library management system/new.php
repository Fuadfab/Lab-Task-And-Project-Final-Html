<?php

class guru{
  public $sifu;
  
  public function getName()
  {
      return $this->sifu;
  }
  
  public function setName($name)
  {
      $this->sifu=$name;
  }
}

$ob1 =new guru;

$obl->setName("Shifat");
echo $ob1->getName(); 

?>